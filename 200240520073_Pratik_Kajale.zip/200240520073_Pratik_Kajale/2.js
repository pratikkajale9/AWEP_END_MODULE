function exam()
{
    let a = document.querySelector("#user1").value;
    let b = document.querySelector("#pass1").value;
    let c = document.querySelector("#user");
    let d = document.querySelector("#pass");
    if(a == "" || b == "" )
    {
    {
        if(a != "")
        alert("Enter Your PassWord ");
    }
    if(b != "")
    {
        alert("Enter Your UserName ");
    }
    if(a == "" & b == "")
    {
        alert("Enter Username and password ");
    }
    }
    else
    {
        c.innerHTML = "Username is : " + a;
        d.innerHTML = "Password is : " + b;

    }
    document.querySelector("#user1").value = "";
    document.querySelector("#pass1").value = "";


}